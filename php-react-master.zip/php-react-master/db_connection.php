<?php
$db_conn = mysqli_connect("localhost","root","","react_php_crud");